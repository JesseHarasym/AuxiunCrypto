//Step 1 - Install web3js https://web3js.readthedocs.io/en/v1.2.0/getting-started.html
//Step 2 - Learn how to call methods from the smart contract https://web3js.readthedocs.io/en/v1.3.4/web3-eth-contract.html (Hint: Go to the methods example on the page.)
//Step 3 - Understand the difference between web3's call() and send() methods https://bitsofco.de/calling-smart-contract-functions-using-web3-js-call-vs-send/#:~:text=The%20difference%20between%20the%20call,the%20state%20of%20the%20contract.


//These are the local variables that you will need. 
const Web3 = require("web3"); //Requiring web3.
const ganacheNetwork = "http://localhost:8545"; //This is our connection for ganache (Allows for easy testing)
var web3 = new Web3(Web3.currentProvider || ganacheNetwork); //Setting the connection either to the currentProvider or Ganache.
const compiledContract = require("../build/contracts/Coin.json"); //Grabbing the json version of our contract.
const contract_address = "0x137C9De2129220890eaf83284fC651C629F040d6"; //This will be address of the contract on the blockchain (Specific to my Ganache project. Once your deploy the contract on you machine change the address accordingly)
const abi = compiledContract.abi; //Gets the abi of our compiled contract.

var contractDetails = new web3.eth.Contract(abi, contract_address); //Allows to access the contracts details (Methods, events, constants, etc.) 



    
const getAccountZero = async () => {
    /*
        TODO create an async function to grab the first account in the blockchain.
        Purpose: The address that is returned will be used for minting new coins.

        -You will need a variable to store the accounts.
        -Go here https://web3js.readthedocs.io/en/v1.3.4/web3-eth.html to find the method you need to grab the accounts.
        
            Return only the first account. 
    */
};
    

const getBalance = (address) => {
    /*
    TODO create a function which can be used to call the getBalance function from the ERC20 contract.
    
    Purpose: Allows us to get the balance of a specific account. 

        -The ERC20 getBalance function takes in an address.
        -You will use the contractDetails variable that I included to call the function from the contract. 
    
        Return either an error or response once the function is executed. 
    */
};


const mint = async (receiver, amount) => {
    /*
    TODO create a function which can be used to call the mint function from the ERC20 contract.
    
    Purpose: Allows us to mint new coins for a specific user

        -You will use the contractDetails variable that I included to call the function from the contract and send a transaction. 
        -The ERC20 mint function takes in a reciever and amount. 
        -You will use web3's send() since this method alters the state of a contract.
          When you using send you will need to state who is minting the coins. Example .send({from: getAccountZero()}) 

        Return either an error or response once the function is executed. 
    */
  };

  const transfer = (receiver, amount) => {
 /*
    TODO create a function which can be used to call the send function from the ERC20 contract.
    
    Purpose: Allows us to transfer coins between accounts. 

        -You will use the contractDetails variable that I included to call the function from the contract and send a transaction. 
        -The ERC20 mint function takes in a reciever and amount. 
        -You will use web3's send() since this method alters the state of a contract.

        Return either an error or response once the function is executed. 
    */
  };


exports.getBalance = getBalance;
exports.mint = mint;
exports.transfer = transfer;