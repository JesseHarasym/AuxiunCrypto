//Step 1 - Install web3js https://web3js.readthedocs.io/en/v1.2.0/getting-started.html
//Step 2 - Learn how to call methods from the smart contract https://web3js.readthedocs.io/en/v1.3.4/web3-eth-contract.html (Hint: Go to the methods example on the page.)
//Step 3 - Understand the difference between web3's call() and send() methods https://bitsofco.de/calling-smart-contract-functions-using-web3-js-call-vs-send/#:~:text=The%20difference%20between%20the%20call,the%20state%20of%20the%20contract.

//These are the local variables that you will need.
const Web3 = require("web3"); //Requiring web3.
const ganacheNetwork = "http://localhost:8545"; //This is our connection for ganache (Allows for easy testing)
var web3 = new Web3(Web3.currentProvider || ganacheNetwork); //Setting the connection either to the currentProvider or Ganache.
const compiledContract = require("../build/contracts/GameAssets.json"); //Grabbing the json version of our contract.
const contract_address = "0x38fFD5e4e1A5c3f9445D659EeC70722057a36d4f"; //This will be address of the contract on the blockchain (Specific to my Ganache project. Once you deploy the contract on your machine change the address accordingly)
const abi = compiledContract.abi; //Gets the abi of our compiled contract.

var contractDetails = new web3.eth.Contract(abi, contract_address); //Allows to access the contracts details (Methods, events, constants, etc.)

const createItem = (uri, creator) => {
  /*
        TODO create a function which can be used to call the createItem function from the ERC721 contract.
        Purpose: Allows us to create a new NFT.

        -The ERC721 createItem takes in a uri which will be set to the token.
        -You will use the contractDetails variable that I included to call the function from the contract. 
        -You will use web3's send() since this method alters the state of a contract.
        -When you using send you will need to state who is creating the item. Example .send({from: creator}) 
        
        Return either an error or response once the function is executed. 
    */
};

const transferItem = (from, to, tokenId) => {
  /*
        TODO create a function which can be used to call the transferItem function from the ERC721 contract.
        Purpose: Allows us to transfer a NFT between two accounts. 

        -The ERC721 transferItem takes in three parameters from, to, and tokenId.
        -You will use the contractDetails variable that I included to call the function from the contract. 
        -You will use web3's send() since this method alters the state of a contract.
        -When you using send you will need to state who is transfering the item. Example .send({from: from}) 
        
        Return either an error or response once the function is executed. 
    */
};

const ownerOfToken = (tokenId) => {
  /*
        TODO create a function which can be used to call the ownerOfToken function from the ERC721 contract.
        Purpose: Allows us to see who owns a specific token. 

        -The ERC721 cownerOfToken takes in a tokenId for its parameters.
        -You will use the contractDetails variable that I included to call the function from the contract. 
        -You will use web3's call() since this method does not alter the state of a contract.
        
        Return either an error or response once the function is executed. 
    */
};

exports.ownerOfToken = ownerOfToken;
exports.createItem = createItem;
exports.transferItem = transferItem;
