const Web3 = require("web3");
const ganacheNetwork = "http://localhost:8545";
var web3 = new Web3(Web3.currentProvider || ganacheNetwork);

const compiledContract = require("../build/contracts/MultiToken.json");
const contract_address = "0x1819Ece303e29824A28848a7cA093408aBF3a2e3";
const abi = compiledContract.abi;
var contractDetails = new web3.eth.Contract(abi, contract_address);

// SINGLE TOKENS
// @params: address to send created token to, token id, token amount, token data
const createToken = (to, id, amount, data) => {
  // TODO:
  // use contracts createToken method with the parameters as to_address, token_id, token_amount, data
  // use send function with  a gas limit of under 5000000
  // if else for error or response handling
};

// @params: owner address, token id
const getTokenBalance = (owner, id) => {
  // use contracts getTokenBalance method with the parameters as address_owner, token_id
  // use call to get error and response
  // if else for error or response handling
};

// @params: address from, address to, token id, token amount, data
const safeTokenTransfer = (from, to, id, amount, data) => {
  // use contracts safeTokenTransfer method with the parameters as address_from, addresss_to, token_id, token_amount, data.
  // yse send function to set from and gas limit, keep under 5000000
  // if else for error or response handling
};

// BATCH TOKENS
// @params, to address, ids array, ammounts array, data
const createBatchTokens = (to, ids, amounts, data) => {
  // TODO
  // same as createToken with ids and amounts as arrays
};

// params@ owner address, ids array
const getBatchBalance = (owner, ids) => {
  // TODO
  // same as getTokenBalance with owners and ids as arrays
};

//address from, address to, token ids, token ammounts, data
const safeBatchTransfer = (from, to, ids, amounts, data) => {
  // TODO
  // same as safeTokenTransfer with ids and ammounts as arrays
};

exports.createToken = createToken;
exports.getTokenBalance = getTokenBalance;
exports.safeTokenTransfer = safeTokenTransfer;
exports.createBatchTokens = createBatchTokens;
exports.getBatchBalance = getBatchBalance;
exports.safeBatchTransfer = safeBatchTransfer;
